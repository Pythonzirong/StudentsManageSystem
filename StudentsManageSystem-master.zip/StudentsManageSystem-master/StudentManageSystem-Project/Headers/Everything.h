#ifndef EVERTTHING_H
#define EVERTTHING_H

#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include "ShowMap.h"
#include <conio.h>
#include <stdbool.h>
#include "FileO.h"
#include "Core1.h"
#include "Core2.h"
#include "Input.h"


#endif // EVERTTHING_H
